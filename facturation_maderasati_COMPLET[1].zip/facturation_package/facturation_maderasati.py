#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================
  GARAGE ALPINE — Facturation MADERASATI
  AO/05/2025 — Lot 1 & Lot 2
  Agrée SNTL 2115
================================================
  Usage : python3 facturation_maderasati.py
"""

import os, sys
from datetime import date
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas

# ─────────────────────────────────────────────
#  CONFIGURATION
# ─────────────────────────────────────────────
LOGO_PATH   = os.path.join(os.path.dirname(__file__), "logo_garage_alpine.png")
OUTPUT_DIR  = os.path.join(os.path.dirname(__file__), "output")
os.makedirs(OUTPUT_DIR, exist_ok=True)

PAGE_W, PAGE_H = A4
BLACK   = colors.HexColor('#000000')
GRAY_BG = colors.HexColor('#f2f2f2')
WHITE   = colors.white

# ─────────────────────────────────────────────
#  BASE DE DONNÉES PARC (extrait — compléter si besoin)
# ─────────────────────────────────────────────
PARC = {
    # Lot 2 — Skhirat-Témara
    "160841": {"mk": "HYUNDAI", "mo": "COUNTY", "pa": "SKHIRAT",        "lot": "2"},
    "160842": {"mk": "HYUNDAI", "mo": "COUNTY", "pa": "SYZ",            "lot": "2"},
    "160843": {"mk": "HYUNDAI", "mo": "COUNTY", "pa": "SYZ",            "lot": "2"},
    "197542": {"mk": "IVECO",   "mo": "DAILY",  "pa": "SKHIRAT",        "lot": "2"},
    "197543": {"mk": "IVECO",   "mo": "DAILY",  "pa": "SYZ",            "lot": "2"},
    "206087": {"mk": "RENAULT", "mo": "MASTER", "pa": "SKHIRAT",        "lot": "2"},
    "206088": {"mk": "RENAULT", "mo": "MASTER", "pa": "SYZ",            "lot": "2"},
    "207899": {"mk": "CITROEN", "mo": "JUMPER", "pa": "SYZ",            "lot": "2"},
    "207901": {"mk": "CITROEN", "mo": "JUMPER", "pa": "SYZ",            "lot": "2"},
    "207903": {"mk": "CITROEN", "mo": "JUMPER", "pa": "SKHIRAT",        "lot": "2"},
    "220708": {"mk": "HYUNDAI", "mo": "H350",   "pa": "SKHIRAT",        "lot": "2"},
    "220715": {"mk": "HYUNDAI", "mo": "H350",   "pa": "SKHIRAT",        "lot": "2"},
    "236374": {"mk": "CITROEN", "mo": "JUMPER", "pa": "SYZ",            "lot": "2"},
    "237757": {"mk": "HYUNDAI", "mo": "H350",   "pa": "SKHIRAT",        "lot": "2"},
    "248364": {"mk": "FIAT",    "mo": "DUCATO", "pa": "SYZ",            "lot": "2"},
    "248365": {"mk": "FIAT",    "mo": "DUCATO", "pa": "SYZ",            "lot": "2"},
    "255348": {"mk": "RENAULT", "mo": "MASTER", "pa": "SKHIRAT",        "lot": "2"},
    "255349": {"mk": "RENAULT", "mo": "MASTER", "pa": "SKHIRAT",        "lot": "2"},
    "259882": {"mk": "RENAULT", "mo": "MASTER", "pa": "SYZ",            "lot": "2"},
    "262178": {"mk": "IVECO",   "mo": "DAILY",  "pa": "SKHIRAT",        "lot": "2"},
    "262179": {"mk": "IVECO",   "mo": "DAILY",  "pa": "SKHIRAT",        "lot": "2"},
    "262180": {"mk": "IVECO",   "mo": "DAILY",  "pa": "SYZ",            "lot": "2"},
    # Lot 1 — Salé
    "217723": {"mk": "FORD",    "mo": "TRANSIT","pa": "AMEUR-BOUKNADEL","lot": "1"},
    "217724": {"mk": "FORD",    "mo": "TRANSIT","pa": "AMEUR-BOUKNADEL","lot": "1"},
    "222355": {"mk": "RENAULT", "mo": "MASTER", "pa": "AMEUR-BOUKNADEL","lot": "1"},
    "222356": {"mk": "RENAULT", "mo": "MASTER", "pa": "AMEUR-BOUKNADEL","lot": "1"},
    "236869": {"mk": "CITROEN", "mo": "JUMPER", "pa": "AMEUR-BOUKNADEL","lot": "1"},
    "236870": {"mk": "CITROEN", "mo": "JUMPER", "pa": "AMEUR-BOUKNADEL","lot": "1"},
    "236976": {"mk": "CITROEN", "mo": "JUMPER", "pa": "EL ARJAT-SEHOUL","lot": "1"},
    "238403": {"mk": "FORD",    "mo": "TRANSIT","pa": "AMEUR-BOUKNADEL","lot": "1"},
    "253448": {"mk": "CITROEN", "mo": "JUMPER", "pa": "AMEUR-BOUKNADEL","lot": "1"},
    "254656": {"mk": "FIAT",    "mo": "DUCATO", "pa": "EL ARJAT-SEHOUL","lot": "1"},
    "254657": {"mk": "FIAT",    "mo": "DUCATO", "pa": "EL ARJAT-SEHOUL","lot": "1"},
    "254675": {"mk": "RENAULT", "mo": "MASTER", "pa": "EL ARJAT-SEHOUL","lot": "1"},
    "254686": {"mk": "RENAULT", "mo": "MASTER", "pa": "AMEUR-BOUKNADEL","lot": "1"},
    "259876": {"mk": "RENAULT", "mo": "MASTER", "pa": "EL ARJAT-SEHOUL","lot": "1"},
    "262173": {"mk": "IVECO",   "mo": "DAILY",  "pa": "AMEUR-BOUKNADEL","lot": "1"},
    "262174": {"mk": "IVECO",   "mo": "DAILY",  "pa": "AMEUR-BOUKNADEL","lot": "1"},
    "262175": {"mk": "IVECO",   "mo": "DAILY",  "pa": "EL ARJAT-SEHOUL","lot": "1"},
}

# ─────────────────────────────────────────────
#  ARTICLES PAR TYPE D'INTERVENTION
# ─────────────────────────────────────────────
def get_items(mk, mo, intervention, ht):
    """Retourne la liste des articles selon intervention + marque/modèle."""
    key = f"{mk}-{mo}"
    if intervention == "1":   # Vidange complète
        if key == "HYUNDAI-COUNTY":
            return [
                {"qte":"8","desig":"Huile à Moteur",               "ref":"5W30",       "marque":"VIPER",   "pu":"90,00",  "pt":"720,00"},
                {"qte":"1","desig":"Filtre à gasoil",               "ref":"3194545700", "marque":"HYUNDAI", "pu":"120,00", "pt":"120,00"},
                {"qte":"1","desig":"Filtreà Huile",                 "ref":"P3033",      "marque":"BOSCH",   "pu":"130,00", "pt":"130,00"},
                {"qte":"1","desig":"Filtre à Air",                  "ref":"281305H002", "marque":"HYUNDAI", "pu":"240,00", "pt":"240,00"},
                {"qte":"1","desig":"Main D'oeuvre Vidange complete","ref":"-",          "marque":"-",       "pu":"200,00", "pt":"200,00"},
            ]
        else:
            pu_huile = "90,00"; qt_huile = "6"
            return [
                {"qte":qt_huile,"desig":"Huile à Moteur",               "ref":"5W30",  "marque":"VIPER","pu":pu_huile,"pt":str(int(qt_huile)*90)+",00"},
                {"qte":"1","desig":"Filtre à gasoil",               "ref":"WF8494",    "marque":"WIX",  "pu":"90,00", "pt":"90,00"},
                {"qte":"1","desig":"Filtre à Huile",                "ref":"WL7544",    "marque":"WIX",  "pu":"90,00", "pt":"90,00"},
                {"qte":"1","desig":"Filtre à Air",                  "ref":"WA9741",    "marque":"WIX",  "pu":"140,00","pt":"140,00"},
                {"qte":"1","desig":"Main D'oeuvre Vidange complete","ref":"-",         "marque":"-",    "pu":"200,00","pt":"200,00"},
            ]
    # Autres interventions — 1 ligne avec montant global
    labels = {"2":"Système de freinage","3":"Suspension / Direction",
              "4":"Système Embrayage","5":"Réparation moteur","6":"Autre intervention"}
    return [{"qte":"1","desig":labels.get(intervention,"Prestation"),"ref":"-","marque":"-",
             "pu":f"{ht:,.2f}".replace(",",""),"pt":f"{ht:,.2f}".replace(",","")}]

# ─────────────────────────────────────────────
#  MONTANT EN LETTRES
# ─────────────────────────────────────────────
def montant_en_lettres(n):
    n = round(n)
    u = ['','un','deux','trois','quatre','cinq','six','sept','huit','neuf','dix',
         'onze','douze','treize','quatorze','quinze','seize','dix-sept','dix-huit','dix-neuf']
    d = ['','','vingt','trente','quarante','cinquante','soixante','soixante','quatre-vingt','quatre-vingt']
    def b100(x):
        if x < 20: return u[x]
        t, r = divmod(x, 10)
        if t in (7,9): return d[t]+('-et-' if r==1 and t==7 else '-')+u[10+r]
        return d[t]+('-et-' if r==1 and t!=8 else ('-'+u[r] if r else ''))
    def b1000(x):
        if x < 100: return b100(x)
        h, r = divmod(x, 100)
        return ('cent' if h==1 else u[h]+' cent')+(' '+b100(r) if r else '')
    if n == 0: return 'zéro'
    if n < 1000: return b1000(n)
    k, r = divmod(n, 1000)
    return ('mille' if k==1 else b1000(k)+' mille')+(' '+b1000(r) if r else '')

# ─────────────────────────────────────────────
#  EN-TÊTE COMMUN (Logo + infos)
# ─────────────────────────────────────────────
def draw_header(c, doc_label, num, date_, client, ice, lot, commande, marque, matricule, km):
    if os.path.exists(LOGO_PATH):
        c.drawImage(LOGO_PATH, 10*mm, PAGE_H-38*mm, width=85*mm, height=28*mm,
                    preserveAspectRatio=True, anchor='nw', mask='auto')
    c.setFont('Helvetica', 6.5); c.setFillColor(BLACK)
    c.drawCentredString(PAGE_W/2, PAGE_H-42*mm,
        'Mécanique Général - Diagnostic par scanner - Electricité Auto - Carrosserie – Pièces de rechange')
    c.setFont('Helvetica-Bold', 11)
    c.drawCentredString(PAGE_W/2, PAGE_H-49*mm, 'Agrée par SNTL 2115')
    y_sep = PAGE_H - 52*mm
    c.setStrokeColor(BLACK); c.setLineWidth(0.5)
    c.line(10*mm, y_sep, PAGE_W-10*mm, y_sep)
    y0 = y_sep - 6*mm; lh = 5.5*mm
    left  = [('Le :', date_), (f'{doc_label} N° :', num),
             ('N Commande :', commande), ('Client :', client),
             ('ICE:', ice + '    Lot : ' + lot)]
    right = [('Marque:', marque), ('M :', str(matricule)),
             ('KM :', f"{int(km):,}".replace(',',' ')), ('',''), ('SYZ','')]
    for i,(lb,val) in enumerate(left):
        y = y0 - i*lh
        c.setFont('Helvetica-Bold',8.5); c.setFillColor(BLACK); c.drawString(10*mm, y, lb)
        c.setFont('Helvetica',8.5); c.drawString(40*mm, y, val)
    for i,(lb,val) in enumerate(right):
        y = y0 - i*lh
        if lb:
            c.setFont('Helvetica-Bold',8.5); c.drawString(120*mm, y, lb)
            c.setFont('Helvetica',8.5); c.drawString(138*mm, y, val)
    return y0 - len(left)*lh - 4*mm

# ─────────────────────────────────────────────
#  TABLEAU GÉNÉRIQUE
# ─────────────────────────────────────────────
def draw_table(c, y, col_w, headers, items, empty_col=None, min_rows=20):
    x0 = 10*mm; row_h = 6.5*mm; hdr_h = 7.5*mm
    c.setFillColor(WHITE); c.setStrokeColor(BLACK); c.setLineWidth(0.6)
    c.rect(x0, y-hdr_h, sum(col_w), hdr_h, fill=1, stroke=1)
    c.setFillColor(BLACK); c.setFont('Helvetica-Bold', 8)
    xx = x0
    for h,w in zip(headers, col_w):
        c.drawCentredString(xx+w/2, y-hdr_h+2.5*mm, h); xx+=w
    y -= hdr_h
    total_rows = max(len(items), min_rows)
    for idx in range(total_rows):
        bg = GRAY_BG if idx%2==1 else WHITE
        c.setFillColor(bg); c.setStrokeColor(BLACK); c.setLineWidth(0.3)
        c.rect(x0, y-row_h, sum(col_w), row_h, fill=1, stroke=1)
        if idx < len(items):
            row = items[idx]
            c.setFillColor(BLACK); c.setFont('Helvetica', 8)
            xx = x0
            for i,(v,w) in enumerate(zip([str(row[k]) for k in row], col_w)):
                if i==0 or (empty_col and i>=empty_col): c.drawCentredString(xx+w/2, y-row_h+2*mm, v)
                else: c.drawString(xx+2*mm, y-row_h+2*mm, v)
                xx+=w
        elif empty_col:
            c.setFillColor(BLACK); c.setFont('Helvetica',8)
            c.drawCentredString(x0+sum(col_w)-col_w[-1]/2, y-row_h+2*mm, '-')
        y -= row_h
    c.setStrokeColor(BLACK); c.setLineWidth(0.8)
    c.rect(x0, y, sum(col_w), hdr_h+total_rows*row_h, fill=0, stroke=1)
    return y

def draw_footer(c, y):
    box_h = 22*mm
    c.setFillColor(GRAY_BG); c.setStrokeColor(BLACK); c.setLineWidth(0.5)
    c.rect(10*mm, y-box_h, PAGE_W-20*mm, box_h, fill=1, stroke=1)
    c.setFillColor(BLACK); c.setFont('Helvetica', 7.5)
    lines = ['Adresse : Lot Oued Eddahab : N°71 Rue Settat –TEMARA – GSM : /0669555344',
             'Fax :0537644498 R.C N°87718 – Patente N°:27935719- Banque B.M.C.E– Cpt(N°011810000004210000848008)',
             '/ICE:001860625000007  _']
    yy = y-6*mm
    for l in lines: c.drawCentredString(PAGE_W/2, yy, l); yy-=5*mm

# ─────────────────────────────────────────────
#  GÉNÉRATION FACTURE
# ─────────────────────────────────────────────
def generer_facture(d, items, out):
    c = canvas.Canvas(out, pagesize=A4)
    y = draw_header(c,'Facture',d['num'],d['date'],d['client'],d['ice'],
                    d['lot'],d['commande'],d['marque'],d['matricule'],d['km'])
    col_w = [18*mm, 68*mm, 28*mm, 24*mm, 24*mm, 26*mm]
    hdrs  = ['Quantité','Désignation','Ref','Marque','Prix Unitaire','Prix Total']
    rows  = [{k:v for k,v in zip(('qte','desig','ref','marque','pu','pt'),
              [r['qte'],r['desig'],r['ref'],r['marque'],r['pu'],r['pt']])} for r in items]
    y = draw_table(c, y, col_w, hdrs, rows, empty_col=4)
    ht=d['ht']; tva=round(ht*0.2,2); ttc=round(ht+tva,2)
    y -= 2*mm
    for i,(lb,val) in enumerate([('Total HT',f'{ht:,.2f}'.replace(',',' ')),
                                   ('TVA 20%', f'{tva:,.2f}'.replace(',',' ')),
                                   ('Total TTC',f'{ttc:,.2f}'.replace(',',' '))]):
        bold=(i==2)
        c.setFillColor(GRAY_BG if not bold else colors.HexColor('#d9d9d9'))
        c.setStrokeColor(BLACK); c.setLineWidth(0.5)
        c.rect(125*mm, y-7*mm, 75*mm, 7*mm, fill=1, stroke=1)
        c.setFillColor(BLACK); c.setFont('Helvetica-Bold' if bold else 'Helvetica',8.5)
        c.drawString(127*mm, y-5.5*mm, lb)
        c.drawRightString(PAGE_W-12*mm, y-5.5*mm, val)
        y-=7*mm
    y-=4*mm
    c.setFont('Helvetica-Bold',8); c.setFillColor(BLACK)
    c.drawString(10*mm, y, 'La présent facture est arrêtée à la somme de  '
                 + montant_en_lettres(ttc).capitalize()+' dirhams.')
    draw_footer(c, y-12*mm)
    c.save()

# ─────────────────────────────────────────────
#  GÉNÉRATION BL
# ─────────────────────────────────────────────
def generer_bl(d, items, out):
    c = canvas.Canvas(out, pagesize=A4)
    y = draw_header(c,'BL',d['num'],d['date'],d['client'],d['ice'],
                    d['lot'],d['commande'],d['marque'],d['matricule'],d['km'])
    col_w = [18*mm, 88*mm, 36*mm, 38*mm]
    hdrs  = ['Quantité','Désignation','Ref','Marque']
    rows  = [{k:v for k,v in zip(('qte','desig','ref','marque'),
              [r['qte'],r['desig'],r['ref'],r['marque']])} for r in items]
    y = draw_table(c, y, col_w, hdrs, rows)
    draw_footer(c, y-10*mm)
    c.save()

# ─────────────────────────────────────────────
#  INTERFACE PRINCIPALE
# ─────────────────────────────────────────────
def menu_intervention():
    print("\n  Type d'intervention :")
    print("  1. Vidange complète")
    print("  2. Système de freinage")
    print("  3. Suspension / Direction")
    print("  4. Système Embrayage")
    print("  5. Réparation moteur")
    print("  6. Autre")
    return input("  Choix (1-6) : ").strip()

def main():
    print("=" * 52)
    print("  GARAGE ALPINE — Facturation MADERASATI")
    print("  AO/05/2025  |  Agrée SNTL 2115")
    print("=" * 52)

    while True:
        print("\n  ┌─────────────────────────────────┐")
        print("  │  1. Générer Facture + BL        │")
        print("  │  2. Générer BL uniquement       │")
        print("  │  3. Générer Facture uniquement  │")
        print("  │  0. Quitter                     │")
        print("  └─────────────────────────────────┘")
        choix = input("  Votre choix : ").strip()
        if choix == "0": print("\n  Au revoir!\n"); break

        # ── Saisie données ──────────────────
        print("\n  ── Saisie ──────────────────────────")
        num       = input("  N° Facture/BL (ex: AO/05/2025-L2-187) : ").strip()
        matricule = input("  Matricule véhicule (ex: 160843) : ").strip()

        # Recherche auto dans le parc
        if matricule in PARC:
            v = PARC[matricule]
            mk=v['mk']; mo=v['mo']; pa=v['pa']; lot=v['lot']
            marque_full = f"{mk}-{mo}"
            print(f"\n  ✓ Véhicule trouvé : {marque_full} | Parc : {pa} | Lot : {lot}")
        else:
            print(f"\n  ⚠ Matricule {matricule} non trouvé dans le parc.")
            mk  = input("  Marque (ex: HYUNDAI) : ").upper().strip()
            mo  = input("  Modèle (ex: COUNTY) : ").upper().strip()
            pa  = input("  Parc/Zone : ").upper().strip()
            lot = input("  Lot (1 ou 2) : ").strip()
            marque_full = f"{mk}-{mo}"

        km   = input("  KM actuel : ").strip()
        d_   = input(f"  Date (Entrée = aujourd'hui {date.today().strftime('%d/%m/%y')}) : ").strip()
        date_= d_ if d_ else date.today().strftime('%d/%m/%y')

        intervention = menu_intervention()
        ht_input     = input("  Total HT (DH) : ").strip().replace(',','.')
        ht           = float(ht_input)

        items = get_items(mk, mo, intervention, ht)

        data = {
            "num"       : num,
            "date"      : date_,
            "client"    : "Maderasati",
            "ice"       : "003343121000053",
            "lot"       : lot,
            "commande"  : "AO/05/2025",
            "marque"    : marque_full,
            "matricule" : matricule,
            "km"        : km,
            "ht"        : ht,
        }

        # Noms fichiers
        safe_num   = num.replace("/","_").replace(" ","-")
        f_facture  = os.path.join(OUTPUT_DIR, f"Facture_{safe_num}.pdf")
        f_bl       = os.path.join(OUTPUT_DIR, f"BL_{safe_num}.pdf")

        if choix in ("1","3"): generer_facture(data, items, f_facture)
        if choix in ("1","2"): generer_bl(data, items, f_bl)

        print("\n  ✅ Documents générés dans le dossier 'output/' :")
        if choix in ("1","3"): print(f"     📄 {os.path.basename(f_facture)}")
        if choix in ("1","2"): print(f"     📋 {os.path.basename(f_bl)}")

        cont = input("\n  Générer un autre document ? (o/n) : ").strip().lower()
        if cont != 'o': print("\n  Au revoir!\n"); break

if __name__ == "__main__":
    main()
